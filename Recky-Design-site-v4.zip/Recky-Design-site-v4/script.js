const $=(s)=>document.querySelector(s);const $$=(s)=>document.querySelectorAll(s);
$('#year').textContent=new Date().getFullYear();
const nav=$('#mainNav'),menu=$('#menuToggle');
menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',open)});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

$$('.filters button').forEach(btn=>btn.addEventListener('click',()=>{ $$('.filters button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const filter=btn.dataset.filter;$$('.work').forEach(card=>card.classList.toggle('hidden',filter!=='all'&&card.dataset.cat!==filter)); }));

const modal=$('#orderModal'),form=$('#orderForm'),service=$('#service');
function openOrder(selected=''){if(selected){service.value=selected}modal.classList.add('show');modal.setAttribute('aria-hidden','false');document.body.classList.add('lock');setTimeout(()=>service.focus(),50)}
function closeOrder(){modal.classList.remove('show');modal.setAttribute('aria-hidden','true');document.body.classList.remove('lock')}
$$('[data-open-order]').forEach(b=>b.addEventListener('click',()=>openOrder()));
$$('[data-service]').forEach(b=>b.addEventListener('click',()=>openOrder(b.dataset.service)));
$$('[data-close-modal]').forEach(b=>b.addEventListener('click',closeOrder));
modal.addEventListener('click',e=>{if(e.target===modal)closeOrder()});
form.addEventListener('submit',e=>{e.preventDefault();const s=service.value,f=$('#format').value.trim(),d=$('#details').value.trim();let msg=`Bonjour Recky Désign,\n\nJe viens du site et je souhaite commander : ${s}.`;if(f)msg+=`\nFormat / précision : ${f}.`;if(d)msg+=`\nMa demande : ${d}`;msg+='\n\nMerci.';window.open('https://wa.me/243831397111?text='+encodeURIComponent(msg),'_blank','noopener');});

const lightbox=$('#lightbox'),lbImg=$('#lightboxImg'),lbTitle=$('#lightboxTitle');
$$('.image-btn').forEach(b=>b.addEventListener('click',()=>{lbImg.src=b.dataset.image;lbImg.alt=b.dataset.title;lbTitle.textContent=b.dataset.title;lightbox.classList.add('show');lightbox.setAttribute('aria-hidden','false');document.body.classList.add('lock')}));
function closeLightbox(){lightbox.classList.remove('show');lightbox.setAttribute('aria-hidden','true');document.body.classList.remove('lock');lbImg.src=''}
$$('[data-close-lightbox]').forEach(b=>b.addEventListener('click',closeLightbox));
lightbox.addEventListener('click',e=>{if(e.target===lightbox)closeLightbox()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeOrder();closeLightbox()}});
