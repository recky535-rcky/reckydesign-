RECKY DÉSIGN — SITE V4

Cette version est préparée pour la mise en ligne :
- portfolio des réalisations réelles fournies
- filtres de galerie + affichage plein écran
- services et commande WhatsApp préremplie
- formulaire de commande
- tarifs portraits A6 à A0
- section À propos + fonctionnement
- FAQ
- optimisation mobile/tablette/ordinateur
- métadonnées SEO de base, icône et manifest web
- robots.txt et sitemap.xml à adapter au vrai nom de domaine

TEST LOCAL : ouvrir index.html dans un navigateur.

MISE EN LIGNE :
1. Choisir un hébergeur (gratuit ou payant).
2. Choisir/acheter le nom de domaine.
3. Remplacer l'URL example.com dans sitemap.xml par le vrai domaine.
4. Envoyer tout le contenu de ce dossier sur l'hébergement.
5. Activer HTTPS.
6. Tester les boutons WhatsApp et toutes les images depuis un téléphone.

WhatsApp : 0831397111
Marque : Recky Désign
Slogan : Donne vie à vos idées
